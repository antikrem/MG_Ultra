
UserdataMetatable
========================


.. doxygenclass:: kaguya::UserdataMetatable
  :members:
