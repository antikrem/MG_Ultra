
LuaFunction
==================================

.. doxygenclass:: kaguya::LuaFunction
  :members:
