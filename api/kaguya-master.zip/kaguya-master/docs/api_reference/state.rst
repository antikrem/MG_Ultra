
State
==================================
State is lua_State* wrapper class

.. doxygenclass:: kaguya::State
  :members:
