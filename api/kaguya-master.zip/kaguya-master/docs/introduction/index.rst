
Introduction
==================================

Kaguya is Lua binding library for C++

* header-file only
* Seamless access to lua elements
* Type-safe and decent speed `benchmark <http://satoren.github.io/lua_binding_benchmark/>`_
* Support old environment. see :doc:`../getting_started/requirements`

License
---------------------------------------
Licensed under Boost Software License
