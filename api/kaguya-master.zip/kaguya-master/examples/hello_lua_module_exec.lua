
hello_module = require('hello_lua_module')

hello_module.hello()
